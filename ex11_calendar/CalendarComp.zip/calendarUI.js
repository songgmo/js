var sCalendarBasicUI = '
<div id="calendar_layer" class="calendar show"> 
	<div> 
		<a href="#" class="calendar btn-prev-year">이전연</a> 
		<a href="#" class="calendar btn-prev-mon">이전달</a> 
		<strong class="calendar title"></strong> 
		<a href="#" class="calendar btn-next-mon">다음달</a> 
		<a href="#" class="calendar btn-next-year">다음연</a> 
	</div> 
	<table> 
	<thead> 
		<tr> 
			<th>일</th><th>월</th><th>화</th><th>수</th><th>목</th><th>금</th><th>토</th> 
		</tr> 
	</thead> 
	<tbody> 
		<tr class="week"> 
			<td class="date"></td> 
			<td class="date"></td> 
			<td class="date"></td> 
			<td class="date"></td> 
			<td class="date"></td> 
			<td class="date"></td> 
			<td class="date"></td> 
		</tr> 
	</tbody> 
	</table> 
</div>';